﻿using eShopping.Models;
using Microsoft.EntityFrameworkCore;

namespace eShopping.Services
{
    public class CategoryDataService : IDataAccessService<Category, int>
    {
        EshopingContext ctx;
        ResponseObject<Category> response;

        public CategoryDataService(EshopingContext ctx)
        {
            this.ctx = ctx;
            response = new ResponseObject<Category>();

        }

        async Task<ResponseObject<Category>> IDataAccessService<Category, int>.CreateAsync(Category entity)
        {
            var result =  await ctx.Categories.AddAsync(entity);
            await ctx.SaveChangesAsync();
            response.Record = result.Entity;
            response.Message = "new Record is Created";
            response.StatusCode = 200;
            return response;
        }

        async Task<ResponseObject<Category>> IDataAccessService<Category, int>.DeleteAsync(int id)
        {
            response.Record = await ctx.Categories.FindAsync(id);
            if(response.Record == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                ctx.Categories.Remove(response.Record);
                await ctx.SaveChangesAsync();
                response.Message = "Record is deleted";
                response.StatusCode = 200;
            }

            return response;
        }

        async Task<ResponseObject<Category>> IDataAccessService<Category, int>.GetAsync()
        {
            response.Records= await this.ctx.Categories.ToListAsync();
            response.Message = "Records are read";
            response.StatusCode = 200;
            return response;
        }

        async Task<ResponseObject<Category>> IDataAccessService<Category, int>.GetAsync(int id)
        {
            response.Record = await ctx.Categories.FindAsync(id);

            if (response.Records == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                response.Message = "Record is found";
                response.StatusCode = 200;
            }

            return response;
        }

        public async Task<ResponseObject<Category>> UpdateAsync(int id, Category entity)
        {
            response.Record = await ctx.Categories.FindAsync(id);

            if (response.Record == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                response.Record.Name = entity.Name;
                await ctx.SaveChangesAsync();
                response.Message = "Record is found";
                response.StatusCode = 200;
            }

            return response;
        }
    }
}
