﻿using eShopping.Models;
using Microsoft.EntityFrameworkCore;

namespace eShopping.Services
{
    public class ProductDataService : IDataAccessService<Product, int>
    {
        EshopingContext ctx;
        ResponseObject<Product> response;

        public ProductDataService(EshopingContext ctx)
        {
            this.ctx = ctx;
            response = new ResponseObject<Product>();

        }

        async Task<ResponseObject<Product>> IDataAccessService<Product, int>.CreateAsync(Product entity)
        {
            //  entity.CreatedById = DateTime.Now;
            var result = await ctx.Products.AddAsync(entity);
            await ctx.SaveChangesAsync();
            response.Record = result.Entity;
            response.Message = "new Record is Created";
            response.StatusCode = 200;
            return response;
        }

        async Task<ResponseObject<Product>> IDataAccessService<Product, int>.DeleteAsync(int id)
        {
            response.Record = await ctx.Products.FindAsync(id);
            if (response.Record == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                ctx.Products.Remove(response.Record);
                await ctx.SaveChangesAsync();
                response.Message = "Record is deleted";
                response.StatusCode = 200;
            }

            return response;
        }

        async Task<ResponseObject<Product>> IDataAccessService<Product, int>.GetAsync()
        {
            response.Records = await this.ctx.Products.ToListAsync();
            response.Message = "Records are read";
            response.StatusCode = 200;
            return response;
        }

        async Task<ResponseObject<Product>> IDataAccessService<Product, int>.GetAsync(int id)
        {
            response.Record = await ctx.Products.FindAsync(id);
            if (response.Record == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                var category = await ctx.Categories.FindAsync(response?.Record?.CategoryId);
                response.Record.CategoryName = category != null ? category.Name : string.Empty;
                response.Message = "Record is found";
                response.StatusCode = 200;
            }

            return response;
        }

        public async Task<ResponseObject<Product>> UpdateAsync(int id, Product entity)
        {
            response.Record = await ctx.Products.FindAsync(id);

            if (response.Record == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                response.Record.Name = entity.Name;
                // response.Record.UpdatedAt = DateTime.Now;
                await ctx.SaveChangesAsync();
                response.Message = "Record is found";
                response.StatusCode = 200;
            }

            return response;
        }
    }
}
