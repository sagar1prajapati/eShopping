﻿using eShopping.Models;
using Microsoft.EntityFrameworkCore;

namespace eShopping.Services
{
    public class UserDataService : IDataAccessService<User, int>
    {
        EshopingContext ctx;
        ResponseObject<User> response;

        public UserDataService(EshopingContext ctx)
        {
            this.ctx = ctx;
            response = new ResponseObject<User>();

        }

        async Task<ResponseObject<User>> IDataAccessService<User, int>.CreateAsync(User entity)
        {
            entity.CreatedAt = DateTime.Now;
            var result =  await ctx.Users.AddAsync(entity);
            await ctx.SaveChangesAsync();
            response.Record = result.Entity;
            response.Message = "new Record is Created";
            response.StatusCode = 200;
            return response;
        }

        async Task<ResponseObject<User>> IDataAccessService<User, int>.DeleteAsync(int id)
        {
            response.Record = await ctx.Users.FindAsync(id);
            if(response.Record == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                ctx.Users.Remove(response.Record);
                await ctx.SaveChangesAsync();
                response.Message = "Record is deleted";
                response.StatusCode = 200;
            }

            return response;
        }

        async Task<ResponseObject<User>> IDataAccessService<User, int>.GetAsync()
        {
            response.Records= await this.ctx.Users.ToListAsync();
            response.Message = "Records are read";
            response.StatusCode = 200;
            return response;
        }

        async Task<ResponseObject<User>> IDataAccessService<User, int>.GetAsync(int id)
        {
            response.Record = await ctx.Users.FindAsync(id);

            if (response.Records == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                response.Message = "Record is found";
                response.StatusCode = 200;
            }

            return response;
        }

        public async Task<ResponseObject<User>> UpdateAsync(int id, User entity)
        {
            response.Record = await ctx.Users.FindAsync(id);

            if (response.Record == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                response.Record.Name = entity.Name;
                response.Record.UpdatedAt = DateTime.Now;
                await ctx.SaveChangesAsync();
                response.Message = "Record is found";
                response.StatusCode = 200;
            }

            return response;
        }
    }
}
