﻿using eShopping.Models;
using Microsoft.EntityFrameworkCore;

namespace eShopping.Services
{
    public class ManufacturerDataService : IDataAccessService<Manufacturer, int>
    {
        EshopingContext ctx;
        ResponseObject<Manufacturer> response;

        public ManufacturerDataService(EshopingContext ctx)
        {
            this.ctx = ctx;
            response = new ResponseObject<Manufacturer>();

        }

        async Task<ResponseObject<Manufacturer>> IDataAccessService<Manufacturer, int>.CreateAsync(Manufacturer entity)
        {
            entity.CreatedAt = DateTime.Now;
            var result =  await ctx.Manufacturers.AddAsync(entity);
            await ctx.SaveChangesAsync();
            response.Record = result.Entity;
            response.Message = "new Record is Created";
            response.StatusCode = 200;
            return response;
        }

        async Task<ResponseObject<Manufacturer>> IDataAccessService<Manufacturer, int>.DeleteAsync(int id)
        {
            response.Record = await ctx.Manufacturers.FindAsync(id);
            if(response.Record == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                ctx.Manufacturers.Remove(response.Record);
                await ctx.SaveChangesAsync();
                response.Message = "Record is deleted";
                response.StatusCode = 200;
            }

            return response;
        }

        async Task<ResponseObject<Manufacturer>> IDataAccessService<Manufacturer, int>.GetAsync()
        {
            response.Records= await this.ctx.Manufacturers.ToListAsync();
            response.Message = "Records are read";
            response.StatusCode = 200;
            return response;
        }

        async Task<ResponseObject<Manufacturer>> IDataAccessService<Manufacturer, int>.GetAsync(int id)
        {
            response.Record = await ctx.Manufacturers.FindAsync(id);

            if (response.Records == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                response.Message = "Record is found";
                response.StatusCode = 200;
            }

            return response;
        }

        public async Task<ResponseObject<Manufacturer>> UpdateAsync(int id, Manufacturer entity)
        {
            response.Record = await ctx.Manufacturers.FindAsync(id);

            if (response.Record == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                response.Record.Name = entity.Name;
                response.Record.UpdatedAt = DateTime.Now;
                await ctx.SaveChangesAsync();
                response.Message = "Record is found";
                response.StatusCode = 200;
            }

            return response;
        }
    }
}
