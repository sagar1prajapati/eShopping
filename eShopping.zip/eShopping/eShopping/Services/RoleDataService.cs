﻿using eShopping.Models;
using Microsoft.EntityFrameworkCore;

namespace eShopping.Services
{
    public class RoleDataService : IDataAccessService<Role, int>
    {
        EshopingContext ctx;
        ResponseObject<Role> response;

        public RoleDataService(EshopingContext ctx)
        {
            this.ctx = ctx;
            response = new ResponseObject<Role>();

        }

        async Task<ResponseObject<Role>> IDataAccessService<Role, int>.CreateAsync(Role entity)
        {
            var result =  await ctx.Roles.AddAsync(entity);
            await ctx.SaveChangesAsync();
            response.Record = result.Entity;
            response.Message = "new Record is Created";
            response.StatusCode = 200;
            return response;
        }

        async Task<ResponseObject<Role>> IDataAccessService<Role, int>.DeleteAsync(int id)
        {
            response.Record = await ctx.Roles.FindAsync(id);
            if(response.Record == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                ctx.Roles.Remove(response.Record);
                await ctx.SaveChangesAsync();
                response.Message = "Record is deleted";
                response.StatusCode = 200;
            }

            return response;
        }

        async Task<ResponseObject<Role>> IDataAccessService<Role, int>.GetAsync()
        {
            response.Records= await this.ctx.Roles.ToListAsync();
            response.Message = "Records are read";
            response.StatusCode = 200;
            return response;
        }

        async Task<ResponseObject<Role>> IDataAccessService<Role, int>.GetAsync(int id)
        {
            response.Record = await ctx.Roles.FindAsync(id);

            if (response.Records == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                response.Message = "Record is found";
                response.StatusCode = 200;
            }

            return response;
        }

        public async Task<ResponseObject<Role>> UpdateAsync(int id, Role entity)
        {
            response.Record = await ctx.Roles.FindAsync(id);

            if (response.Record == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                response.Record.Name = entity.Name;
                await ctx.SaveChangesAsync();
                response.Message = "Record is found";
                response.StatusCode = 200;
            }

            return response;
        }
    }
}
