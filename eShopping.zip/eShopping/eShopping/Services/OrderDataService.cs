﻿using eShopping.Models;
using Microsoft.EntityFrameworkCore;

namespace eShopping.Services
{
    public class OrderDataService : IDataAccessService<Order, int>
    {
        EshopingContext ctx;
        ResponseObject<Order> response;

        public OrderDataService(EshopingContext ctx)
        {
            this.ctx = ctx;
            response = new ResponseObject<Order>();

        }

        async Task<ResponseObject<Order>> IDataAccessService<Order, int>.CreateAsync(Order entity)
        {
            entity.CreatedAt = DateTime.Now;
            var result = await ctx.Orders.AddAsync(entity);
            await ctx.SaveChangesAsync();
            response.Record = result.Entity;
            response.Message = "new Record is Created";
            response.StatusCode = 200;
            return response;
        }

        async Task<ResponseObject<Order>> IDataAccessService<Order, int>.DeleteAsync(int id)
        {
            response.Record = await ctx.Orders.FindAsync(id);
            if (response.Record == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                ctx.Orders.Remove(response.Record);
                await ctx.SaveChangesAsync();
                response.Message = "Record is deleted";
                response.StatusCode = 200;
            }

            return response;
        }

        async Task<ResponseObject<Order>> IDataAccessService<Order, int>.GetAsync()
        {
            response.Records = await this.ctx.Orders.ToListAsync();
            response.Message = "Records are read";
            response.StatusCode = 200;
            return response;
        }

        async Task<ResponseObject<Order>> IDataAccessService<Order, int>.GetAsync(int id)
        {
            response.Record = await ctx.Orders.FindAsync(id);

            if (response.Records == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                response.Message = "Record is found";
                response.StatusCode = 200;
            }

            return response;
        }

        public async Task<ResponseObject<Order>> UpdateAsync(int id, Order entity)
        {
            response.Record = await ctx.Orders.FindAsync(id);

            if (response.Record == null)
            {
                response.Message = "Record is no found";
                response.StatusCode = 400;
            }
            else
            {
                response.Record.Price = entity.Price;
                // response.Record.UpdatedAt = DateTime.Now;
                await ctx.SaveChangesAsync();
                response.Message = "Record is found";
                response.StatusCode = 200;
            }

            return response;
        }
    }
}
