﻿using System;
using System.Collections.Generic;

namespace eShopping.Models;

public partial class Bill
{
    public int Id { get; set; }

    public string PaymentMode { get; set; }

    public int? OrderId { get; set; }

    public string Status { get; set; }

    public virtual Order Order { get; set; }
}
