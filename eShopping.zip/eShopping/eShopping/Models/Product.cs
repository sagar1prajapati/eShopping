﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace eShopping.Models;

public partial class Product : EntityBase
{
    public int Id { get; set; }

    public string Name { get; set; }

    public int? CategoryId { get; set; }

    public int? ManufacturerId { get; set; }

    public int? CreatedById { get; set; }

    public decimal? Price { get; set; }

    [NotMapped]
    public string CategoryName { get; set; }
    public virtual Category Category { get; set; }

    public virtual User CreatedBy { get; set; }

    public virtual Manufacturer Manufacturer { get; set; }

    //public virtual ICollection<OrderProductMapping> OrderProductMappings { get; set; } = new List<OrderProductMapping>();
}
