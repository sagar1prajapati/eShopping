﻿using System;
using System.Collections.Generic;

namespace eShopping.Models;

public partial class Order : EntityBase
{
    public int Id { get; set; }

    public int? CreatedById { get; set; }

    public decimal? Price { get; set; }

    public DateTime CreatedAt { get; set; }

    public DateTime? UpdatedAt { get; set; }

    public DateTime? DeletedAt { get; set; }

    public virtual ICollection<Bill> Bills { get; set; } = new List<Bill>();

    public virtual User CreatedBy { get; set; }

    public virtual ICollection<OrderProductMapping> OrderProductMappings { get; set; } = new List<OrderProductMapping>();
}
