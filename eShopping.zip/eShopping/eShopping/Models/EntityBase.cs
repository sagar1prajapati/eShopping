﻿namespace eShopping.Models
{
    public abstract class EntityBase
    {
    }
}
