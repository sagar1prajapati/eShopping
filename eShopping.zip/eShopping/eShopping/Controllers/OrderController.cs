﻿using eShopping.Models;
using eShopping.Services;
using eShopping.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Xml.Schema;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace eShopping.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        IDataAccessService<Order, int> orderServ;
        IDataAccessService<Product, int> prodServ;
        public OrderController(IDataAccessService<Order, int> _orderServ
            , IDataAccessService<Product, int> _prodServ)
        {
            orderServ = _orderServ;
            prodServ = _prodServ;
        }
        [HttpGet]
        [ActionName("get")]
        public async Task<IActionResult> Get()
        {
            var response = await orderServ.GetAsync();
            return Ok(response);
        }

        //[HttpGet("{id}")]
        //[ActionName("getbyid")]
        //public async Task<IActionResult> Get(int id)
        //{
        //   var response = await orderServ.GetAsync(id);
        //    return Ok(response);
        //}

        [HttpPost]
        [ActionName("Add")]
        public async Task<IActionResult> Post(OrderViewModel orderVM)
        {
            if (ModelState.IsValid)
            {
                var order = new Order();
                order.OrderProductMappings = new List<OrderProductMapping>();
                decimal? finalTotal = 0;
                foreach (var item in orderVM.OrderProductMappings)
                {
                    
                    var product =   (from u in (await prodServ.GetAsync()).Records
                        where u.Name.Trim() == item.ProductName.ToString()
                        select u).FirstOrDefault();

                    var orderProductMaping = new OrderProductMapping();
                    orderProductMaping.OrderId = order.Id;

                    orderProductMaping.ProductId = product?.Id;

                    orderProductMaping.Quantity = item.Quantity;

                    orderProductMaping.Price = product?.Price;

                    finalTotal = finalTotal + ( Convert.ToDecimal(orderProductMaping.Quantity) * orderProductMaping.Price);

                    order.OrderProductMappings.Add(orderProductMaping);
                }
               
                order.Price = finalTotal;
                order.CreatedById = orderVM.CreatedById;
                

                var response = await orderServ.CreateAsync(order);
                return Ok(response);


            }
            var errorResponse = new ResponseObject<Order>();
            errorResponse.Message = $"Internal Server";
            return BadRequest(errorResponse);
        }

        //[HttpPut("{id}")]
        //[ActionName("put")]
        //public async Task<IActionResult> Put(int id, Order order)
        //{
        //    if (id == 0) throw new Exception($"ID {id} Can not be zero");
        //    var response = await orderServ.UpdateAsync(id , order);
        //    return Ok(response);
        //}


        //[HttpDelete("{id}")]
        //[ActionName("delete")]
        //public async Task<IActionResult> Delete(int id)
        //{
        //    var response = await orderServ.DeleteAsync(id);
        //    return Ok(response);
        //}



       
    }
}
