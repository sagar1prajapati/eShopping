﻿using eShopping.Models;
using eShopping.Services;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace eShopping.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ManufacturerController : ControllerBase
    {
        IDataAccessService<Manufacturer, int> manufacturerServ;
        public ManufacturerController(IDataAccessService<Manufacturer, int> _manufacturer)
        {
            manufacturerServ = _manufacturer;
        }
        [HttpGet]
        [ActionName("get")]
        public async Task<IActionResult> Get()
        {
            var response = await manufacturerServ.GetAsync();
            return Ok(response);
        }

        [HttpGet("{id}")]
        [ActionName("getbyid")]
        public async Task<IActionResult> Get(int id)
        {
           var response = await manufacturerServ.GetAsync(id);
            return Ok(response);
        }

        [HttpPost]
        [ActionName("Add")]
        public async Task<IActionResult> Post(Manufacturer manufacturer)
        {
            if (ModelState.IsValid)
            {
                if(!await IsManufacturerNameAlreadyExist(manufacturer.Name))
                {
                    var response = await manufacturerServ.CreateAsync(manufacturer);
                    return Ok(response);
                }

            }
            var errorResponse = new ResponseObject<Manufacturer>();
            errorResponse.Message = $"Manufacturer with Name: {manufacturer.Name} is already exist";
            return BadRequest(errorResponse);
        }

        [HttpPut("{id}")]
        [ActionName("put")]
        public async Task<IActionResult> Put(int id, Manufacturer manufacturer)
        {
            if (id == 0) throw new Exception($"ID {id} Can not be zero");
            var response = await manufacturerServ.UpdateAsync(id , manufacturer);
            return Ok(response);
        }


        [HttpDelete("{id}")]
        [ActionName("delete")]
        public async Task<IActionResult> Delete(int id)
        {
            var response = await manufacturerServ.DeleteAsync(id);
            return Ok(response);
        }



        private async Task<bool> IsManufacturerNameAlreadyExist(string Name)
        {
            bool isExist = true;

            var user = (from u in (await manufacturerServ.GetAsync()).Records
                          where u.Name.Trim() == Name.Trim()
                          select u).FirstOrDefault();

            if (user == null)
                isExist = false;
            return isExist;
        }
    }
}
