﻿using eShopping.Models;
using eShopping.Services;
using eShopping.ViewModels;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace eShopping.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        IDataAccessService<Product, int> prodServ;
        IDataAccessService<Category, int> categoryServ;
        IDataAccessService<Manufacturer, int> manufacturerServ;
        IDataAccessService<User, int> userServ;
        public ProductController(IDataAccessService<Product, int> _prodServ, 
            IDataAccessService<Category, int> _categoryServ,
                    IDataAccessService<Manufacturer, int> _manufacturerServ,
        IDataAccessService<User, int> _userServ
)
        {
            prodServ = _prodServ;
            categoryServ = _categoryServ;
            manufacturerServ = _manufacturerServ;
            userServ = _userServ;
        }



        [HttpGet]
        [ActionName("get")]
        public async Task<IActionResult> Get()
        {
            var response = await prodServ.GetAsync();
            return Ok(response);
        }

        [HttpGet("{id}")]
        [ActionName("getbyid")]
        public async Task<IActionResult> Get(int id)
        {
            var response = await prodServ.GetAsync(id);
            return Ok(response);
        }

        [HttpPost]
        [ActionName("Add")]
        public async Task<IActionResult> Post(ProductViewModel modal)
        {
            if (ModelState.IsValid)
            {
                var product = new Product()
                {
                    Id = 0,
                    Name = modal.Name,
                    Price = modal.Price,
                    CategoryId = modal.CategoryId,
                    Category = categoryServ.GetAsync(modal.CategoryId).Result.Record,
                    ManufacturerId = modal.ManufacturerId,
                    Manufacturer = manufacturerServ.GetAsync(modal.ManufacturerId).Result.Record,
                    CreatedById = modal.CreatedById,
                    CreatedBy = userServ.GetAsync(modal.CreatedById).Result.Record,
                };
                if (!await IsProductNameAlreadyExist(product.Name))
                {
                    var response = await prodServ.CreateAsync(product);
                    return Ok(response);
                }
            }
            var errorResponse = new ResponseObject<Product>();
            errorResponse.Message = $"Product with Name: {modal.Name} is already exist";
            return BadRequest(errorResponse);
        }

        [HttpPut("{id}")]
        [ActionName("put")]
        public async Task<IActionResult> Put(int id, Product product)
        {
            if (id == 0) throw new Exception($"ID {id} Can not be zero");
            var response = await prodServ.UpdateAsync(id, product);
            return Ok(response);
        }


        [HttpDelete("{id}")]
        [ActionName("delete")]
        public async Task<IActionResult> Delete(int id)
        {
            var response = await prodServ.DeleteAsync(id);
            return Ok(response);
        }



        private async Task<bool> IsProductNameAlreadyExist(string productName)
        {
            bool isExist = true;

            var user = (from u in (await prodServ.GetAsync()).Records
                        where u.Name.Trim() == productName.Trim()
                        select u).FirstOrDefault();

            if (user == null)
                isExist = false;
            return isExist;
        }
    }
}
