﻿using eShopping.Models;
using eShopping.Services;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace eShopping.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        IDataAccessService<Category, int> categoryServ;
        public CategoryController(IDataAccessService<Category, int> _categoryServ)
        {
            categoryServ = _categoryServ;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var response = await categoryServ.GetAsync();
            return Ok(response);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
           var response = await categoryServ.GetAsync(id);
            return Ok(response);
        }

        [HttpPost]
        [ActionName("Add")]
        public async Task<IActionResult> Post(Category category)
        {
            if (ModelState.IsValid)
            {
                if(!await IsCategoryNameAlreadyExist(category.Name))
                {
                    var response = await categoryServ.CreateAsync(category);
                    return Ok(response);
                }

            }
            var errorResponse = new ResponseObject<Category>();
            errorResponse.Message = $"Category with CategoryName: {category.Name} is already exist";
            return BadRequest(errorResponse);
        }

        [HttpPut("{id}")]
        [ActionName("put")]
        public async Task<IActionResult> Put(int id, Category category)
        {
            if (id == 0) throw new Exception($"ID {id} Can not be zero");
            var response = await categoryServ.UpdateAsync(id ,category);
            return Ok(response);
        }


        [HttpDelete("{id}")]
        [ActionName("delete")]
        public async Task<IActionResult> Delete(int id)
        {
            var response = await categoryServ.DeleteAsync(id);
            return Ok(response);
        }



        private async Task<bool> IsCategoryNameAlreadyExist(string CategoryName)
        {
            bool isExist = true;

            var Catgry = (from c in (await categoryServ.GetAsync()).Records
                          where c.Name.Trim() == CategoryName.Trim()
                          select c).FirstOrDefault();

            if (Catgry == null)
                isExist = false;
            return isExist;
        }
    }
}
