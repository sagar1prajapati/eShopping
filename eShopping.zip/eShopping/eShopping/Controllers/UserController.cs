﻿using eShopping.Models;
using eShopping.Services;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace eShopping.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        IDataAccessService<User, int> userServ;
        public UserController(IDataAccessService<User, int> _userServ)
        {
            userServ = _userServ;
        }
        [HttpGet]
        [ActionName("get")]
        public async Task<IActionResult> Get()
        {
            var response = await userServ.GetAsync();
            return Ok(response);
        }

        [HttpGet("{id}")]
        [ActionName("getbyid")]
        public async Task<IActionResult> Get(int id)
        {
           var response = await userServ.GetAsync(id);
            return Ok(response);
        }

        [HttpPost]
        [ActionName("Add")]
        public async Task<IActionResult> Post(User user)
        {
            if (ModelState.IsValid)
            {
                if(!await IsUserNameAlreadyExist(user.Name))
                {
                    var response = await userServ.CreateAsync(user);
                    return Ok(response);
                }

            }
            var errorResponse = new ResponseObject<User>();
            errorResponse.Message = $"Users with Name: {user.Name} is already exist";
            return BadRequest(errorResponse);
        }

        [HttpPut("{id}")]
        [ActionName("put")]
        public async Task<IActionResult> Put(int id, User user)
        {
            if (id == 0) throw new Exception($"ID {id} Can not be zero");
            var response = await userServ.UpdateAsync(id , user);
            return Ok(response);
        }


        [HttpDelete("{id}")]
        [ActionName("delete")]
        public async Task<IActionResult> Delete(int id)
        {
            var response = await userServ.DeleteAsync(id);
            return Ok(response);
        }



        private async Task<bool> IsUserNameAlreadyExist(string UserName)
        {
            bool isExist = true;

            var user = (from u in (await userServ.GetAsync()).Records
                          where u.Name.Trim() == UserName.Trim()
                          select u).FirstOrDefault();

            if (user == null)
                isExist = false;
            return isExist;
        }
    }
}
