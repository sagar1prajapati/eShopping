﻿using eShopping.Models;
using eShopping.Services;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace eShopping.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoleController : ControllerBase
    {
        IDataAccessService<Role, int> roleServ;
        public RoleController(IDataAccessService<Role, int> _roleServ)
        {
            roleServ = _roleServ;
        }
        [HttpGet]
        [ActionName("get")]
        public async Task<IActionResult> Get()
        {
            var response = await roleServ.GetAsync();
            return Ok(response);
        }

        [HttpGet("{id}")]
        [ActionName("getbyid")]
        public async Task<IActionResult> Get(int id)
        {
           var response = await roleServ.GetAsync(id);
            return Ok(response);
        }

        [HttpPost]
        [ActionName("Add")]
        public async Task<IActionResult> Post(Role role)
        {
            if (ModelState.IsValid)
            {
                if(!await IsRoleNameAlreadyExist(role.Name))
                {
                    var response = await roleServ.CreateAsync(role);
                    return Ok(response);
                }

            }
            var errorResponse = new ResponseObject<Category>();
            errorResponse.Message = $"Roles with Name: {role.Name} is already exist";
            return BadRequest(errorResponse);
        }

        [HttpPut("{id}")]
        [ActionName("put")]
        public async Task<IActionResult> Put(int id, Role role)
        {
            if (id == 0) throw new Exception($"ID {id} Can not be zero");
            var response = await roleServ.UpdateAsync(id , role);
            return Ok(response);
        }


        [HttpDelete("{id}")]
        [ActionName("delete")]
        public async Task<IActionResult> Delete(int id)
        {
            var response = await roleServ.DeleteAsync(id);
            return Ok(response);
        }



        private async Task<bool> IsRoleNameAlreadyExist(string RoleName)
        {
            bool isExist = true;

            var role = (from r in (await roleServ.GetAsync()).Records
                          where r.Name.Trim() == RoleName.Trim()
                          select r).FirstOrDefault();

            if (role == null)
                isExist = false;
            return isExist;
        }
    }
}
