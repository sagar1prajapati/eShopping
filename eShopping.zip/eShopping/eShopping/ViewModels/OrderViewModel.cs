﻿using eShopping.Models;

namespace eShopping.ViewModels
{
    public class OrderViewModel
    {
     //   public int Id { get; set; }

        public int? CreatedById { get; set; }

     //   public decimal? Price { get; set; }

        public virtual ICollection<OrderProductMappingViewModel> OrderProductMappings { get; set; } = new List<OrderProductMappingViewModel>();
    }
}
